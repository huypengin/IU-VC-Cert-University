# Notes:

## Objectives

- Create a comprehensive CUD operations tracking mechanism for the configuration service to capture all database changes for audit purposes
- Implement TypeORM entity subscribers to automatically detect Create, Update, Delete operations across all configuration entities
- Capture old and new entity values in JSON format along with client authentication metadata from `ConfigurationLocalStategy` JWT tokens
- Utilize nestjs-cls package for request-scoped async local storage to maintain clientId and request body data throughout the request lifecycle
- Establish TCP communication channel from configuration-service to analytic-service for real-time audit data transmission
- Develop queryable audit API endpoints in analytic-service to support audit trail retrieval and compliance reporting

## Technical Specification

- **Functional Requirements:** 
  - Automatic tracking of all CUD operations on configuration entities (`User`, `Team`, `Role`, `LLM`, `LLMConnection`, `RateLimit`, `ContinueConfiguration`, `DailyUsageTracking`)
  - Capture entity state before and after changes with complete JSON serialization
  - Extract and store clientId from `ConfigurationLocalStategy` JWT authentication token
  - Store request body as old value context for audit correlation
  - Real-time transmission of audit data via NestJS TCP microservices communication
  - RESTful API endpoints for audit data querying with filtering and pagination capabilities

- **Non-Functional Requirements:** 
  - Minimal performance impact on existing configuration service operations
  - Reliable audit data transmission with error handling and retry mechanisms
  - Secure handling of sensitive audit information
  - Scalable MongoDB storage for high-volume audit logs
  - Request-scoped data isolation using async local storage patterns

- **Technical Architecture:** 
  - **Configuration Service Extensions**: TypeORM entity subscribers, nestjs-cls integration, TCP client setup
  - **Analytic Service Extensions**: TCP message pattern handlers, MongoDB audit entity, REST API controllers
  - **Data Flow**: Configuration Service → TCP Message → Analytic Service → MongoDB Storage
  - **Authentication Integration**: JWT token parsing in `ConfigurationLocalStategy` for clientId extraction

- **Data Flow:** 
  1. HTTP request with JWT authentication hits configuration service
  2. `ConfigurationLocalStategy` extracts clientId and stores in nestjs-cls context
  3. Request body captured and stored in nestjs-cls as old value
  4. TypeORM entity subscribers detect database operations (Create/Update/Delete)
  5. Subscribers capture old and new entity states, retrieve clientId from nestjs-cls context
  6. Audit data packaged and sent via TCP to analytic service
  7. Analytic service receives, processes, and stores audit data in MongoDB
  8. Audit API provides queryable access to stored audit trail

- **Implementation Strategy:** 
  - **Approach Selected**: Comprehensive TypeORM Subscriber + nestjs-cls + TCP Communication
  - **Rationale**: Leverages existing NestJS microservices architecture, provides minimal coupling between services, ensures automatic capture of all database operations without manual intervention in business logic
  - **Integration Points**: Extends existing TCP communication patterns, utilizes established MongoDB infrastructure in analytic service
  - **Backward Compatibility**: Non-intrusive implementation that doesn't affect existing functionality

- **Success Criteria:** 
  - All CUD operations on configuration entities automatically generate audit entries
  - Audit entries contain complete old/new state, clientId, timestamps, and operation metadata
  - TCP communication successfully transmits audit data with <100ms latency
  - Audit API responds to queries within 200ms for standard filtering operations
  - Zero disruption to existing configuration service performance benchmarks
  - Comprehensive test coverage for all audit scenarios and edge cases

- **Risk Considerations:** 
  - **Performance Impact**: Mitigation through asynchronous TCP transmission and optimized JSON serialization
  - **Data Volume**: MongoDB indexing strategy and data retention policies to manage growth
  - **TCP Connection Reliability**: Connection pooling, retry logic, and circuit breaker patterns
  - **nestjs-cls Context Loss**: Proper async context propagation and fallback mechanisms
  - **Sensitive Data Exposure**: Data sanitization and access control for audit information

# Ticket Id:

apps-191625

# Task List

- [x] **High-Level Task 1:** Install and Configure Dependencies
  - [x] 1.1: Install `nestjs-cls` package using `pnpm add nestjs-cls` for request-scoped async local storage functionality
  - [x] 1.2: Update configuration service environment variables to include `ANALYTIC_SERVICE_TCP_HOST` and `ANALYTIC_SERVICE_TCP_PORT` in Joi validation schema in `apps/configuration-service/src/configuration-service.module.ts`
  - [x] 1.3: Update analytic service environment variables to include `ANALYTIC_TCP_PORT` in Joi validation schema in `apps/analytic-service/src/analytic-service.module.ts`

- [x] **High-Level Task 2:** Create Audit Data Structures
  - [x] 2.1: Create `AuditLog` entity in `libs/common/src/entities/audit-log.entity.ts` extending `AbstractEntity` with fields: `entityName: string`, `entityId: number`, `operation: AuditOperationEnum`, `oldValue: object`, `newValue: object`, `clientId: string`, `requestMetadata: object`
  - [x] 2.2: Create `CreateAuditLogDto` in `libs/common/src/dtos/create-audit-log.dto.ts` with `@IsEnum`, `@IsNotEmpty`, `@IsObject` validation decorators matching `AuditLog` entity fields
  - [x] 2.3: Create `AuditLogQueryDto` in `libs/common/src/dtos/audit-log-query.dto.ts` with optional filtering fields `entityName`, `entityId`, `operation`, `clientId`, `dateFrom`, `dateTo`, `page`, `limit` using `@IsOptional` decorators
  - [x] 2.4: Create audit operation enum `AuditOperationEnum` in `libs/common/src/constants/audit-operation.enum.ts` with string values `'CREATE'`, `'UPDATE'`, `'DELETE'`
  - [x] 2.5: Create TCP message patterns constants `TCP_CREATE_AUDIT_LOG = 'create-audit-log'` and `TCP_QUERY_AUDIT_LOGS = 'query-audit-logs'` in `libs/common/src/constants/tcp-patterns.constants.ts`
  - [x] 2.6: Export `AuditLog` in `libs/common/src/entities/index.ts`, export DTOs in `libs/common/src/dtos/index.ts`, export enum and TCP patterns in `libs/common/src/constants/index.ts`

- [ ] **High-Level Task 3:** Implement nestjs-cls Integration in Configuration Service
  - [ ] 3.1: Configure `ClsModule.forRoot({ global: true, middleware: { mount: true } })` in `apps/configuration-service/src/configuration-service.module.ts` imports array for request isolation
  - [ ] 3.2: Create `AuditContextService` in `apps/configuration-service/src/services/audit-context.service.ts` with `@Injectable()` decorator, inject `ClsService`, provide methods `setClientId(clientId: string)`, `getClientId(): string`, `setRequestBody(body: any)`, `getRequestBody(): any`
  - [ ] 3.3: Create `AuditContextInterceptor` in `apps/configuration-service/src/interceptors/audit-context.interceptor.ts` implementing `NestInterceptor`, inject `AuditContextService` (from task 3.2), capture `request.body` in `intercept()` method and call `setRequestBody()`
  - [ ] 3.4: Modify `ConfigurationLocalStategy.validate()` method in `apps/configuration-service/src/strategies/local.strategy.ts` to inject `AuditContextService` (from task 3.2) and call `setClientId(clientId)` after successful validation
  - [ ] 3.5: Register `AuditContextInterceptor` (from task 3.3) in global interceptors array in `apps/configuration-service/src/configuration-service.module.ts` providers using `APP_INTERCEPTOR` token

- [ ] **High-Level Task 4:** Create TypeORM Entity Subscribers for Audit Tracking
  - [ ] 4.1: Create `EntityAuditSubscriber` in `apps/configuration-service/src/subcribers/entity-audit.subscriber.ts` with `@EventSubscriber()` decorator implementing `EntitySubscriberInterface`, use `listenTo()` method to return `Object` for all entities
  - [ ] 4.2: Implement `beforeUpdate(event: UpdateEvent<any>)` method to store `event.entity` state in private Map using `event.entity.id` as key for old value tracking
  - [ ] 4.3: Implement `afterInsert(event: InsertEvent<any>)`, `afterUpdate(event: UpdateEvent<any>)`, `afterRemove(event: RemoveEvent<any>)` methods to call `AuditDataProcessor.processAuditEvent()` (from task 4.4) with operation type and entity data
  - [ ] 4.4: Create `AuditDataProcessor` service in `apps/configuration-service/src/services/audit-data-processor.service.ts` with `@Injectable()` decorator, inject `AuditContextService` (from task 3.2) and `AuditLogService` (from task 5.3), implement `processAuditEvent(operation: AuditOperationEnum, entity: any, oldValue?: any)` method to create `CreateAuditLogDto` (from task 2.2) and send via TCP
  - [ ] 4.5: Register `EntityAuditSubscriber` and `AuditDataProcessor` in `apps/configuration-service/src/configuration-service.module.ts` providers array to enable TypeORM entity event subscription

- [ ] **High-Level Task 5:** Implement TCP Communication for Audit Data Transmission
  - [ ] 5.1: Configure TCP client in `apps/configuration-service/src/configuration-service.module.ts` imports using `ClientsModule.registerAsync({ name: 'ANALYTIC_SERVICE', useFactory: (config: ConfigService) => ({ transport: Transport.TCP, options: { host: config.get('ANALYTIC_SERVICE_TCP_HOST'), port: config.get('ANALYTIC_SERVICE_TCP_PORT') } }) })`
  - [ ] 5.2: Create `AuditLogService` in `apps/configuration-service/src/services/audit-log.service.ts` with `@Injectable()` decorator, inject `@Inject('ANALYTIC_SERVICE') private client: ClientProxy`, implement `sendAuditLog(auditData: CreateAuditLogDto)` method using `client.emit(TCP_CREATE_AUDIT_LOG, auditData)` (from task 2.5)
  - [ ] 5.3: Implement error handling in `AuditLogService.sendAuditLog()` method with try-catch block, logging failed transmissions using NestJS Logger, implement retry logic with exponential backoff for failed TCP connections
  - [ ] 5.4: Register `AuditLogService` in `apps/configuration-service/src/configuration-service.module.ts` providers array and inject into `AuditDataProcessor.processAuditEvent()` (from task 4.4) to send audit data asynchronously

- [ ] **High-Level Task 6:** Extend Analytic Service for Audit Data Storage
  - [ ] 6.1: Update `apps/analytic-service/src/main.ts` to add microservice connection with `app.connectMicroservice({ transport: Transport.TCP, options: { host: '0.0.0.0', port: configService.get('ANALYTIC_TCP_PORT') } })` and call `app.startAllMicroservices()`
  - [ ] 6.2: Create `AuditLogDocument` MongoDB schema in `apps/analytic-service/src/schemas/audit-log.schema.ts` using `@Schema()` decorator with fields matching `AuditLog` entity (from task 2.1), add indexes on `entityName`, `entityId`, `operation`, `clientId`, `createdAt`
  - [ ] 6.3: Create `AuditLogRepository` in `apps/analytic-service/src/repositories/audit-log.repository.ts` extending `AbstractRepository` from `@app/common/mongodb`, inject `AuditLogDocument` (from task 6.2), implement `create()`, `findByQuery()`, `findById()` methods
  - [ ] 6.4: Create `AuditLogService` in `apps/analytic-service/src/services/audit-log.service.ts` with `@Injectable()` decorator, inject `AuditLogRepository` (from task 6.3), implement `createAuditLog(data: CreateAuditLogDto)`, `queryAuditLogs(query: AuditLogQueryDto)`, `findById(id: string)` methods
  - [ ] 6.5: Create `AuditLogController` in `apps/analytic-service/src/controllers/audit-log.controller.ts` with `@Controller()` decorator, inject `AuditLogService` (from task 6.4), implement `@MessagePattern(TCP_CREATE_AUDIT_LOG)` method to receive audit data and call `createAuditLog()`
  - [ ] 6.6: Register `AuditLogDocument` (from task 6.2) using `MongoDatabaseModule.forFeature()`, register `AuditLogRepository` (from task 6.3), `AuditLogService` (from task 6.4), and `AuditLogController` (from task 6.5) in `apps/analytic-service/src/analytic-service.module.ts` providers and controllers arrays

- [ ] **High-Level Task 7:** Implement Audit Query API in Analytic Service
  - [ ] 7.1: Create `AuditLogHttpController` in `apps/analytic-service/src/controllers/audit-log-http.controller.ts` with `@Controller('audit-logs')` decorator, inject `AuditLogService` (from task 6.4), apply `JwtAdminVerifierGuard` using `@UseGuards()` decorator
  - [ ] 7.2: Implement `@Get()` endpoint method with `@Query() query: AuditLogQueryDto` (from task 2.3) parameter, call `AuditLogService.queryAuditLogs()` (from task 6.4) and return paginated results with metadata
  - [ ] 7.3: Implement `@Get(':id')` endpoint method with `@Param('id') id: string` parameter, call `AuditLogService.findById()` (from task 6.4) and return single audit log entry
  - [ ] 7.4: Enhance `AuditLogRepository.findByQuery()` (from task 6.3) to support MongoDB `skip()` and `limit()` operations using `page` and `limit` fields from `AuditLogQueryDto` (from task 2.3), return total count for pagination metadata
  - [ ] 7.5: Register `AuditLogHttpController` in `apps/analytic-service/src/analytic-service.module.ts` controllers array, ensure `JwtSymetricKeyVerifier` provider is available for JWT authentication

# Current Goal

**High-Level Task 3: Implement nestjs-cls Integration in Configuration Service**