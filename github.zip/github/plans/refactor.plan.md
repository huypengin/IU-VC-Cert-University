# Refactor Plan
            
## Overview

This document contains refactoring tasks identified from recent code changes.
Each task MUST be completed to ensure code quality and adherence to coding standards.

## Task Status Legend

- `[ ]` - Incomplete task
- `[x]` - Completed task

## Refactor Items

- [x] File: apps/analytic-service/src/constants/pagination.constants.ts **Compliant**: All code adheres to coding standards
- [x] File: libs/common/src/interfaces/index.ts **Compliant**: All code adheres to coding standards
- [x] File: libs/common/src/enums/audit-operation.enum.ts **Compliant**: All code adheres to coding standards
- [x] File: libs/common/src/schemas/index.ts **Compliant**: All code adheres to coding standards
- [x] File: libs/common/src/dtos/index.ts **Compliant**: All code adheres to coding standards
- [x] File: apps/configuration-service/src/configuration-service.module.ts **Compliant**: All code adheres to coding standards
- [x] File: apps/analytic-service/src/analytic-service.module.ts **Compliant**: All code adheres to coding standards
- [x] File: libs/common/src/index.ts **Compliant**: All code adheres to coding standards
- [x] File: libs/common/src/enums/index.ts **Compliant**: All code adheres to coding standards
[x] File: libs/common/src/dtos/create-audit-log.dto.ts
    - **Standard Reference**: No hardcoded strings or numbers (Constants & Enums)
    - **Resolution**:
        1. Define string type values (such as 'string') as named constants in a dedicated /constants directory.
        2. Replace all occurrences of hardcoded string literals in property type annotations with the corresponding named constant.
[x] File: libs/common/src/interfaces/audit-metadata.interface.ts
    - **Standard Reference**: No hardcoded strings or numbers (Constants & Enums)
    - **Resolution**:
        1. Define named constants for each string property type (e.g., IP_ADDRESS, USER_AGENT, CLIENT_ID) in a dedicated /constants directory within /libs/common/src.
        2. Replace the direct use of string types in the interface with the corresponding constant or enum references.
[ ] File: apps/configuration-service/src/modules/audit/request-context.service.ts
    - **Standard Reference**: Constants and Enums Locations (Project Structure & Organization)
    - **Resolution**:
        1. Move all constant declarations (UNKNOWN_VALUE, INVALID_JWT_FORMAT_ERROR, BEARER_PREFIX, BEARER_PREFIX_LENGTH, USER_AGENT_HEADER, X_FORWARDED_FOR_HEADER, X_REAL_IP_HEADER, JWT_PARTS_COUNT) from request-context.service.ts to a new file, e.g., apps/configuration-service/src/constants/audit.constants.ts.
        2. Import these constants into request-context.service.ts from the new constants file.
[ ] File: apps/configuration-service/src/subscribers/entity-audit.subscriber.ts
    - **Standard Reference**: No hardcoded strings or numbers, Magic Strings (Constants & Enums)
    - **Resolution**:
        1. Move the following string literals to a dedicated constants file within /src/constants:
           - 'system'
           - '[REDACTED]'
           - 'unknown'
           - Error log message prefixes such as 'Failed to audit insert event: ', 'Failed to audit update event: ', 'Failed to audit remove event: '
        2. Import these constants from the constants file and use them in place of the hardcoded strings.
[ ] File: apps/configuration-service/src/modules/audit/jwt-client-extractor.util.ts
    - **Standard Reference**: Constants and Enums Locations (Project Structure & Organization)
    - **Resolution**:
        1. Move the following constants from jwt-client-extractor.util.ts:
           - BEARER_PREFIX
           - JWT_PARTS_COUNT
           - JWT_DELIMITER
           - UTF8_ENCODING
        2. Create a new file at apps/configuration-service/src/constants/jwt.constants.ts.
        3. Define the constants in jwt.constants.ts and export them.
        4. Import the constants into jwt-client-extractor.util.ts from the new constants file.
[ ] File: libs/common/src/schemas/audit-log.schema.ts
    - **Standard Reference**: No hardcoded strings or numbers (Constants & Enums)
    - **Resolution**:
        1. Define named constants for the collection name and index directions in a dedicated /constants directory (e.g., libs/common/src/constants/audit-log.constants.ts).
        2. Import these constants into audit-log.schema.ts.
        3. Replace all hardcoded strings and numbers in the schema and index definitions with the imported constants.
[ ] File: apps/analytic-service/src/audit-analytic.controller.ts
    - **Standard Reference**: No hardcoded strings or numbers (Constants & Enums)
    - **Resolution**:
        1. Define all route strings as named constants in a dedicated constants file (e.g., audit-analytic.constants.ts) within the /src/constants directory.
        2. Import these constants into audit-analytic.controller.ts.
        3. Replace all hardcoded route strings in decorators with the imported constants.
[ ] File: apps/configuration-service/src/modules/audit/audit.module.ts
    - **Standard Reference**: No hardcoded strings or numbers (Constants & Enums)
    - **Resolution**:
        1. Create a constants file at apps/configuration-service/src/constants/audit.constants.ts.
        2. Define named constants for "ANALYTIC_SERVICE", "localhost", and 3004 in that file.
        3. Import these constants into audit.module.ts.
        4. Replace all hardcoded usages in audit.module.ts with the imported constants.
[ ] File: apps/configuration-service/src/interceptors/audit.interceptor.ts
    - **Standard Reference**: Constants & Enums
    - **Resolution**:
        1. Define the string 'audit' (used in the file name and likely as a concept in the code) as a constant in a dedicated /constants directory within the service's /src folder.
        2. Replace any direct usage of string literals in the code (e.g., 'audit' if used in logic, though not present in this diff) with the imported constant.
        3. If any numeric literals are introduced in future changes, define them as named constants in the /constants directory and use those constants in the code.
- [x] File: apps/configuration-service/src/interceptors/audit.interceptor.ts **Compliant**: All code adheres to coding standards
[ ] File: apps/analytic-service/src/audit-log.repository.ts
    - **Standard Reference**: Constants & Enums
    - **Resolution**:
        1. Create a /src/constants/audit-log.constants.ts file in the analytic-service directory.
        2. Define named constants or enums for all hardcoded strings and numbers:
           - 'timestamp'
           - 'desc'
           - 0
           - 100
           - Any other string options used for query keys (e.g., 'entityName', 'entityId', 'clientId', 'operation')
        3. Import these constants/enums into audit-log.repository.ts.
        4. Replace all hardcoded strings and numbers in audit-log.repository.ts with the imported constants/enums.
[ ] File: apps/configuration-service/src/main.ts
    - **Standard Reference**: Constants & Enums
    - **Resolution**:
        1. Define the path string './interceptors/audit.interceptor' as a constant in a dedicated constants file within /src/constants.
        2. Import the constant into main.ts.
        3. Replace the hardcoded string in the import statement with the constant.
        4. Define AuditInterceptor as a constant or enum in a dedicated constants file within /src/constants.
        5. Import the constant or enum into main.ts.
        6. Replace the direct usage of AuditInterceptor in app.get() with the constant or enum.
[ ] File: apps/configuration-service/src/modules/audit/audit.service.ts
    - **Standard Reference**: Project Structure & Organization (Constants and Enums Locations)
    - **Resolution**:
        1. Move all constant declarations (UNKNOWN_VALUE, CREATE_AUDIT_LOG_EVENT, BEARER_PREFIX, BEARER_PREFIX_LENGTH, USER_AGENT_HEADER, X_FORWARDED_FOR_HEADER, X_REAL_IP_HEADER, JWT_PARTS_COUNT, INVALID_JWT_FORMAT_ERROR, DEFAULT_RETRY_ATTEMPTS, DEFAULT_TIMEOUT_MS, RETRY_DELAY_MS) from audit.service.ts to a new file (e.g., src/modules/audit/constants/audit.constants.ts).
        2. Import the constants from the new constants file into audit.service.ts.
[ ] File: apps/analytic-service/src/analytic-service.service.ts
    - **Standard Reference**: Constants & Enums
    - **Resolution**:
        1. Create or update a constants file (e.g., src/constants/audit.constants.ts) in the service directory.
        2. Define named constants for all hardcoded strings and numbers:
           - export const UNKNOWN_ERROR = 'Unknown error occurred';
           - export const AUDIT_LOG_CREATED_MSG = (entityName: string, entityId: string) => `Audit log created for entity ${entityName}:${entityId}`;
           - export const FAILED_CREATE_AUDIT_LOG_MSG = (errorMessage: string) => `Failed to create audit log: ${errorMessage}`;
           - export const FAILED_GET_AUDIT_HISTORY_MSG = (errorMessage: string) => `Failed to get audit history: ${errorMessage}`;
           - export const DEFAULT_AUDIT_LIMIT = 100;
        3. Import these constants into analytic-service.service.ts.
        4. Replace all hardcoded usages in the code with the corresponding constants.


## Completion Notes

- [ ] All refactor items addressed