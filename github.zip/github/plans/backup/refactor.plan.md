# Refactor Plan
            
## Overview

This document contains refactoring tasks identified from recent code changes.
Each task MUST be completed to ensure code quality and adherence to coding standards.

## Task Status Legend

- `[ ]` - Incomplete task
- `[x]` - Completed task

## Refactor Items

- [x] File: libs/common/src/index.ts **Compliant**: All code adheres to coding standards
- [x] File: libs/common/src/interfaces/index.ts **Compliant**: All code adheres to coding standards
- [x] File: apps/analytic-service/src/analytic-service.module.ts **Compliant**: All code adheres to coding standards
- [x] File: libs/common/src/dtos/index.ts **Compliant**: All code adheres to coding standards
- [x] File: apps/configuration-service/src/configuration-service.module.ts **Compliant**: All code adheres to coding standards
- [x] File: libs/common/src/schemas/index.ts **Compliant**: All code adheres to coding standards
- [x] File: libs/common/src/enums/index.ts **Compliant**: All code adheres to coding standards
[x] File: libs/common/src/enums/audit-operation.enum.ts
    - **Standard Reference**: Project Structure & Organization
    - **Resolution**:
      1. Move `audit-operation.enum.ts` from `libs/common/src/enums/` to `libs/common/src/constants/`.
      2. Update any import paths in the codebase that reference this enum to the new location.
[x] File: libs/common/src/interfaces/audit-metadata.interface.ts
    - **Standard Reference**: Constants & Enums - No hardcoded strings or numbers
    - **Resolution**:
      1. Define named string constants for `ipAddress`, `userAgent`, and `clientId` in a dedicated `/constants` directory.
      2. Import and use these constants in the `AuditMetadata` interface instead of direct string types.
[x] File: apps/configuration-service/src/main.ts
    - **Standard Reference**: Constants & Enums - Magic Strings
    - **Resolution**:
      1. Define a named constant for the route string in a dedicated `/constants` directory within the service's `/src` folder (e.g., `src/constants/routes.constants.ts`).
      2. Import the constant into `main.ts`.
      3. Replace the hardcoded string in `app.get(AuditInterceptor)` with the imported constant.
[x] File: libs/common/src/dtos/create-audit-log.dto.ts
    - **Standard Reference**: Constants & Enums - No hardcoded strings or numbers, Magic Strings
    - **Resolution**:
      1. Define named constants for each string literal type (e.g., for `'string'` used in `entityName`, `entityId`, `clientId`, and `timestamp`) in a dedicated `/constants` file.
      2. Replace direct usage of string literals in DTO property types with the corresponding named constants.
[x] File: apps/configuration-service/src/modules/audit/audit.module.ts
    - **Standard Reference**: Constants & Enums - No hardcoded strings or numbers, Magic Strings/Magic Numbers
    - **Resolution**:
      1. Define named constants for `'ANALYTIC_SERVICE'`, `'localhost'`, and `3004` in a dedicated `/constants` file within the service's `/src` directory.
      2. Import these constants into `audit.module.ts`.
      3. Replace all direct usages of these literals with the imported constants.
[x] File: apps/analytic-service/src/audit-log.repository.ts
    - **Standard Reference**: Constants & Enums - No hardcoded strings or numbers
    - **Resolution**:
      1. Define the following strings and numbers as named constants or enums in a dedicated `/constants` file within the service's `/src` directory:
         - `'timestamp'`
         - `'desc'`
         - `0`
         - `100`
      2. Import these constants into `audit-log.repository.ts` and replace all direct usages with the corresponding constant or enum.
[x] File: libs/common/src/schemas/audit-log.schema.ts
    - **Standard Reference**: Constants & Enums - No hardcoded strings or numbers
    - **Resolution**:
      1. Define named constants for the collection name and index directions in a dedicated `/constants` directory (e.g., `libs/common/src/constants/audit-log.constants.ts`).
      2. Replace all instances of `'audit_logs'`, `1`, and `-1` in the schema and index definitions with the corresponding constants.
[x] File: apps/configuration-service/src/modules/audit/request-context.service.ts
    - **Standard Reference**: Constants and Enums Locations
    - **Resolution**:
      1. Move all constant declarations (`UNKNOWN_VALUE`, `INVALID_JWT_FORMAT_ERROR`, `BEARER_PREFIX`, `BEARER_PREFIX_LENGTH`, `USER_AGENT_HEADER`, `X_FORWARDED_FOR_HEADER`, `X_REAL_IP_HEADER`, `JWT_PARTS_COUNT`) to a new file: `apps/configuration-service/src/constants/request-context.constants.ts`.
      2. Import these constants into `request-context.service.ts` from the new constants file.
[x] File: apps/configuration-service/src/modules/audit/jwt-client-extractor.util.ts
    - **Standard Reference**: Constants and Enums Locations
    - **Resolution**:
      1. Move the following constants: `BEARER_PREFIX`, `JWT_PARTS_COUNT`, `JWT_DELIMITER`, `UTF8_ENCODING` to a new file, e.g., `apps/configuration-service/src/constants/jwt.constants.ts`.
      2. Import these constants from the new constants file into `jwt-client-extractor.util.ts`.
      3. Remove the constant declarations from `jwt-client-extractor.util.ts`.
[x] File: apps/analytic-service/src/audit-analytic.controller.ts
    - **Standard Reference**: Constants & Enums - No hardcoded strings or numbers
    - **Resolution**:
      1. Define all route strings as named constants in a dedicated `constants` file within the service's `/src/constants` directory (e.g., `audit-analytic.constants.ts`).
      2. Import these constants into `audit-analytic.controller.ts`.
      3. Replace all hardcoded route strings in the controller decorators with the corresponding constants.
[x] File: apps/analytic-service/src/analytic-service.service.ts
    - **Standard Reference**: Constants & Enums - No hardcoded strings or numbers
    - **Resolution**:
      1. Define the following strings and numbers as named constants or enums in a dedicated `constants` file within `/src/constants`:
         - `'Unknown error occurred'`
         - `'Failed to create audit log: ...'`
         - `'Audit log created for entity ...'`
         - `'Failed to get audit history: ...'`
         - `100` (default limit for pagination)
      2. Import these constants into `analytic-service.service.ts`.
      3. Replace all direct usages of these literals in the code with the corresponding constant or enum references.
[x] File: apps/configuration-service/src/modules/audit/audit.service.ts
    - **Standard Reference**: Constants and Enums Locations
    - **Resolution**:
      1. Move all constant declarations (`UNKNOWN_VALUE`, `CREATE_AUDIT_LOG_EVENT`, `BEARER_PREFIX`, `BEARER_PREFIX_LENGTH`, `USER_AGENT_HEADER`, `X_FORWARDED_FOR_HEADER`, `X_REAL_IP_HEADER`, `JWT_PARTS_COUNT`, `INVALID_JWT_FORMAT_ERROR`, `DEFAULT_RETRY_ATTEMPTS`, `DEFAULT_TIMEOUT_MS`, `RETRY_DELAY_MS`) to a new file, e.g., `src/modules/audit/constants/audit.constants.ts`.
      2. Import these constants from the new constants file into `audit.service.ts`.
[x] File: apps/configuration-service/src/subscribers/entity-audit.subscriber.ts
    - **Standard Reference**: Constants & Enums - No hardcoded strings or numbers, Magic Strings
    - **Resolution**:
      1. Move the string constants (`SYSTEM_CLIENT_ID`, `REDACTED_VALUE`, `UNKNOWN_ENTITY_ID`) to a dedicated constants file within `/src/constants/entity-audit.constants.ts`.
      2. Import these constants from the new constants file into `entity-audit.subscriber.ts`.
      3. Define error log message templates as named constants in the same constants file and use them in the logger calls.
- [x] File: apps/analytic-service/src/constants/pagination.constants.ts **Compliant**: All code adheres to coding standards
[x] File: apps/configuration-service/src/interceptors/audit.interceptor.ts
    - **Standard Reference**: Constants & Enums - No hardcoded strings or numbers
    - **Resolution**:
      1. Define the string '@nestjs/common' as a constant in a dedicated `/constants` directory within the service's `/src` folder.
      2. Replace all direct usages of '@nestjs/common' in the import statements with the defined constant.
      3. Repeat this process for '../modules/audit/request-context.service' and '../modules/audit/jwt-client-extractor.util'.

      Example:
      **Step 1:** Create a file `apps/configuration-service/src/constants/module-paths.constants.ts`:
      ```typescript
      export const NESTJS_COMMON = '@nestjs/common';
      export const REQUEST_CONTEXT_SERVICE_PATH = '../modules/audit/request-context.service';
      export const JWT_CLIENT_EXTRACTOR_PATH = '../modules/audit/jwt-client-extractor.util';
      ```
      **Step 2:** Update import statements in `audit.interceptor.ts`:
      ```typescript
      import {
        Injectable,
        NestInterceptor,
        ExecutionContext,
        CallHandler,
      } from NESTJS_COMMON;
      import { RequestContextService } from REQUEST_CONTEXT_SERVICE_PATH;
      import { JwtClientExtractor } from JWT_CLIENT_EXTRACTOR_PATH;
      ```

## Completion Notes

- [x] All refactor items addressed